# Matibo English Coach — Android project

Huu ni mradi wa Android Studio unaofunga lessons za offline ndani ya app. Jina la app: **Matibo English Coach**.

## Jinsi ya kutengeneza APK kwenye HP yako (Windows)

1. Sakinisha Android Studio kutoka tovuti rasmi ya Android Developers.
2. Fungua Android Studio → **Open** → chagua folder `MatiboEnglishCoach` baada ya ku-extract ZIP hii.
3. Subiri Gradle sync ikamilike. Ikiombwa, ruhusu kusakinisha Android SDK Platform 35 na Android Gradle Plugin dependencies.
4. Unganisha Pixel 8a kwa USB, washa Developer options na USB debugging, au tumia emulator.
5. Bonyeza **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. APK ya debug kwa majaribio hupatikana kwa kawaida kwenye `app/build/outputs/apk/debug/app-debug.apk`.
7. Hamisha APK kwenye Pixel 8a, ifungue na uruhusu installation kutoka source hiyo ikiwa Android itauliza.

## Vipengele na mipaka

- Lessons, examples, quizzes na UI viko ndani ya APK, kwa hiyo msingi wa masomo hufanya kazi bila internet.
- Progress huhifadhiwa kwenye local storage ya app/WebView.
- Matamshi hutegemea text-to-speech voices zilizopo kwenye kifaa.
- Speech recognition hutegemea WebView/Android service na inaweza kuhitaji internet au ruhusa ya microphone.
- Kitufe cha AI kinafungua ChatGPT online; hakuna AI API key iliyofichwa ndani ya app hii.
- Hii ni build ya majaribio ya binafsi. Kabla ya kuisambaza kwa watu wengine, tunapaswa kuongeza icon/splash screen, kupima vifaa mbalimbali, na kusaini release APK kwa ufunguo unaohifadhiwa salama.

## Kutoa update

Hifadhi source project hii. Kwa kila update ya lessons/UI, badilisha `app/src/main/assets/index.html`, ongeza `versionCode` na `versionName` kwenye `app/build.gradle`, kisha build APK tena. Ili Android isakinishe update juu ya app ya zamani, lazima itumie applicationId na signing key ileile. Usipoteze release signing key.


## Toleo 1.1 — maboresho
- Majibu ya lesson yanahifadhiwa kiotomatiki unapokuwa unaandika.
- Streak ya mazoezi huhesabu siku za kalenda bila kuongeza pointi kwa kubofya complete mara nyingi siku moja.
- Kitufe cha ChatGPT kinafungua mafunzo ya AI kupitia kiungo cha nje kinachotambuliwa na Android WebView.
- Version imepandishwa hadi 1.1; lessons na progress zinaendelea kutumia storage ya app/browser hii.
