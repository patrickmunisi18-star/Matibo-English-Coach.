# Matibo English Coach

Android WebView wrapper for the offline 28-day English course. Includes American/British accent selection, Kiswahili explanations, quizzes, saved progress, text-to-speech when a device voice is installed, optional browser speech recognition, and an online ChatGPT coaching prompt.

Build with `gradle assembleDebug` using JDK 17 and Android Gradle Plugin 8.7.3.

Note: AI coaching opens ChatGPT online; this project does not embed a private AI API key or provide in-app realtime AI speech conversation.
